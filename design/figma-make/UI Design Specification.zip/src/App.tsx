import { useEffect, useState } from "react";

type Screen =
  | "home"
  | "record"
  | "continue"
  | "thinking"
  | "question"
  | "confirm"
  | "result"
  | "switch"
  | "error"
  | "fallback"
  | "empty";

const screens: Screen[] = [
  "home",
  "record",
  "continue",
  "thinking",
  "question",
  "confirm",
  "result",
  "switch",
  "error",
  "fallback",
  "empty",
];

function Icon({ name }: { name: "mic" | "stop" | "sound" | "plus" | "replay" }) {
  const paths = {
    mic: <><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" /></>,
    stop: <rect x="6" y="6" width="12" height="12" rx="2" />,
    sound: <><path d="M4 10v4h4l5 4V6L8 10H4Z" /><path d="M16 9c2 2 2 4 0 6M19 6c4 4 4 8 0 12" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    replay: <><path d="M4 9a8 8 0 1 1 1 7" /><path d="M4 4v5h5" /></>,
  };
  return <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function Mascot({ mood = "happy" }: { mood?: "happy" | "listen" | "think" | "oops" }) {
  return (
    <div className={`mascot mascot--${mood}`} aria-hidden="true">
      <svg viewBox="0 0 180 154">
        <path className="ear" d="M39 47 23 20c-3-6 5-12 11-8l29 20M141 47l16-27c3-6-5-12-11-8l-29 20" />
        <path className="body" d="M39 39c25-24 77-24 102 0 21 21 20 68-2 88-24 23-74 23-98 0-22-20-23-67-2-88Z" />
        <circle className="cheek" cx="48" cy="90" r="10" /><circle className="cheek" cx="132" cy="90" r="10" />
        <circle className="eye" cx="66" cy="75" r="5" /><circle className="eye" cx="114" cy="75" r="5" />
        {mood === "oops" ? <path className="face" d="M78 108c7-7 17-7 24 0" /> : <path className="face" d="M76 99c7 12 21 12 28 0" />}
        {mood === "listen" && <path className="wave" d="M150 60c10 8 10 22 0 30M162 50c17 15 17 37 0 52" />}
        {mood === "think" && <><circle className="thought" cx="149" cy="28" r="6" /><circle className="thought" cx="166" cy="13" r="10" /></>}
      </svg>
    </div>
  );
}

function Action({
  tone,
  children,
  onClick,
  className = "",
}: {
  tone: string;
  children: React.ReactNode;
  onClick: () => void;
  className?: string;
}) {
  return <button className={`action action--${tone} ${className}`} onClick={onClick}>{children}</button>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [direction, setDirection] = useState<"cn" | "se">("cn");
  const [seconds, setSeconds] = useState(30);
  const [thinkingStep, setThinkingStep] = useState(0);

  useEffect(() => {
    if (screen !== "record") return;
    setSeconds(30);
    const timer = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [screen]);

  useEffect(() => {
    if (screen !== "thinking") return;
    setThinkingStep(0);
    const timer = window.setInterval(() => setThinkingStep((value) => Math.min(3, value + 1)), 650);
    const next = window.setTimeout(() => setScreen("question"), 2800);
    return () => { window.clearInterval(timer); window.clearTimeout(next); };
  }, [screen]);

  const from = direction === "cn" ? "🇨🇳" : "🇸🇪";
  const to = direction === "cn" ? "🇸🇪" : "🇨🇳";
  const reset = () => setScreen("home");
  const nextDirection = () => setDirection((value) => value === "cn" ? "se" : "cn");
  const previewNext = () => setScreen(screens[(screens.indexOf(screen) + 1) % screens.length]);

  return (
    <main className="app">
      <header className="topbar">
        <button className={`top-action ${screen === "home" ? "is-hidden" : ""}`} onClick={reset} aria-label="取消">×</button>
        <button className="route" onClick={previewNext} aria-label="预览下一个画面"><span>{from}</span><span className="route-arrow">→</span><span>{to}</span></button>
        <div className="top-actions">
          <button className="top-action" onClick={() => setScreen("switch")} aria-label="切换方向">⇄</button>
          <button className="settings" onClick={() => setScreen("error")} aria-label="成人设置">⚙</button>
        </div>
      </header>

      <section className="stage" aria-live="polite">
        {screen === "home" && (
          <>
            <div className="hero-copy">
              <div className="eyebrow">小翻译 · Lilla Tolken</div>
              <div className="title">你想说什么？</div>
              <div className="subtitle">Vad vill du säga?</div>
            </div>
            <Mascot mood="happy" />
            <div className="home-actions">
              <Action tone="coral" onClick={() => { setDirection("cn"); setScreen("record"); }}>
                <span className="flags">🇨🇳 <span>→</span> 🇸🇪</span><span className="action-label"><Icon name="mic" />按住说中文</span>
                <small>Håll in och prata kinesiska</small>
              </Action>
              <Action tone="sky" onClick={() => { setDirection("se"); setScreen("record"); }}>
                <span className="flags">🇸🇪 <span>→</span> 🇨🇳</span><span className="action-label"><Icon name="mic" />按住说瑞典语</span>
                <small>Håll in och prata svenska</small>
              </Action>
            </div>
          </>
        )}

        {screen === "record" && (
          <>
            <div className="progress-dots"><i className="active" /><i /><i /></div>
            <div className="title compact">我在听</div><div className="subtitle">Jag lyssnar</div>
            <div className={`timer ${seconds <= 5 ? "timer--alert" : ""}`}>
              <svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="53" /><circle className="timer-progress" cx="60" cy="60" r="53" /></svg>
              <strong>{seconds}</strong>
            </div>
            <Mascot mood="listen" />
            <Action tone="coral" className="single-action" onClick={() => setScreen("continue")}><Icon name="stop" /><span>说完这一段</span></Action>
          </>
        )}

        {screen === "continue" && (
          <>
            <div className="progress-dots"><i className="done" /><i /><i /></div>
            <Mascot />
            <div className="title">还要说吗？</div><div className="subtitle">Vill du säga mer?</div>
            <div className="split-actions">
              <Action tone="sky" onClick={() => setScreen("record")}><Icon name="plus" /><span>继续说</span></Action>
              <Action tone="mint" onClick={() => setScreen("thinking")}><span className="big-symbol">✓</span><span>说完了</span></Action>
            </div>
          </>
        )}

        {screen === "thinking" && (
          <>
            <div className="thinking-orbit"><Mascot mood="think" /><i /><i /><i /></div>
            <div className="title">{["听一听", "想一想", "翻译中", "准备声音"][thinkingStep]}</div>
            <div className="subtitle">{["Lyssnar", "Förstår", "Översätter", "Gör rösten klar"][thinkingStep]}…</div>
            <div className="stepper">{["听", "懂", "译", "说"].map((label, index) => <span className={index <= thinkingStep ? "active" : ""} key={label}>{index < thinkingStep ? "✓" : label}</span>)}</div>
          </>
        )}

        {screen === "question" && (
          <>
            <div className="badge">一个小问题 · En liten fråga</div>
            <Mascot mood="listen" />
            <div className="title">你说的是哪一个？</div>
            <div className="adult-note">For adults: Menar barnet den röda eller blå?</div>
            <div className="stack-actions">
              <Action tone="violet" onClick={() => undefined}><Icon name="sound" /><span>再听一次</span></Action>
              <Action tone="coral" onClick={() => setScreen("confirm")}><Icon name="mic" /><span>回答</span></Action>
            </div>
          </>
        )}

        {screen === "confirm" && (
          <>
            <div className="badge">听听看 · Lyssna</div>
            <Mascot />
            <div className="title">是这个意思吗？</div>
            <button className="sound-bubble" aria-label="重放"><Icon name="sound" /></button>
            <div className="split-actions">
              <Action tone="mint" onClick={() => setScreen("result")}><span className="big-symbol">✓</span><span>对！</span></Action>
              <Action tone="coral" onClick={() => setScreen("record")}><span className="big-symbol">×</span><span>不对</span></Action>
            </div>
          </>
        )}

        {screen === "result" && (
          <>
            <div className="delivered"><span>✓</span> 已送达 · Klart!</div>
            <button className="play-orb" aria-label="播放翻译"><Icon name="sound" /></button>
            <div className="title compact">听翻译</div>
            <div className="translation-card">
              <div><small>🇨🇳 原话</small><p>我想要蓝色的杯子。</p></div>
              <div className="divider" />
              <div><small>🇸🇪 Översättning</small><p>Jag vill ha den blå muggen.</p></div>
            </div>
            <div className="result-actions">
              <Action tone="violet" onClick={() => undefined}><Icon name="replay" /><span>再听</span></Action>
              <Action tone="sky" onClick={reset}><Icon name="plus" /><span>新一轮</span></Action>
              <button className="round-retry" onClick={() => setScreen("record")} aria-label="重新录音"><Icon name="mic" /></button>
            </div>
          </>
        )}

        {screen === "switch" && (
          <>
            <div className="switch-symbol">⇄</div>
            <div className="title">换个方向？</div>
            <div className="direction-preview"><span>{to}</span><b>→</b><span>{from}</span></div>
            <div className="stack-actions">
              <Action tone="sky" onClick={() => { nextDirection(); reset(); }}>切换方向</Action>
              <Action tone="cream" onClick={reset}>继续当前方向</Action>
            </div>
          </>
        )}

        {screen === "error" && <MessageScreen symbol="!" title="出了点小问题" note="For adults: 麦克风权限被拒绝，请在 Safari 设置中允许。" primary="再试一次" onPrimary={() => setScreen("record")} onCancel={reset} />}
        {screen === "fallback" && <MessageScreen symbol="?" title="我们换个办法吧" note="For adults: 已达到追问或纠正次数上限。" primary="重新开始" onPrimary={reset} onCancel={reset} />}
        {screen === "empty" && <MessageScreen symbol="耳" title="没有听清楚" note="For adults: 还可以再试 2 次。" primary="再说一遍" onPrimary={() => setScreen("record")} onCancel={reset} />}
      </section>
    </main>
  );
}

function MessageScreen({ symbol, title, note, primary, onPrimary, onCancel }: { symbol: string; title: string; note: string; primary: string; onPrimary: () => void; onCancel: () => void }) {
  return (
    <div className="message-screen">
      <div className="message-symbol">{symbol}</div>
      <Mascot mood="oops" />
      <div className="title">{title}</div>
      <div className="adult-note">{note}</div>
      <div className="stack-actions">
        <Action tone="amber" onClick={onPrimary}>{primary}</Action>
        <Action tone="cream" onClick={onCancel}>取消</Action>
      </div>
    </div>
  );
}
